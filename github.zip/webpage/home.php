<?php
	session_start();
	$name=$_SESSION['use'];
?>
<html>
	<head>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"rel="stylesheet">
		<style>
			.for
			{
				width:700px;
				height:300px;
				border:0px solid #286090;
				padding:60px 30px;
				border-radius:15px;
				line-height:30px;
				margin:0px auto;
				-webkit-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				-moz-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
			}
			h1
			{
				font-family:ariel;
				color: white;
				font-size: 55px;
				text-shadow: rgb(2, 2, 3) -3px -3px 6px;

			}
			.btn
			{
				width:270px;
				height:40px;
			}
			#txt1,#txt2
			{
				border-radius:5px;
				padding-left:15px;
				border:1px solid gray;
			}
			label
			{
				font-size:15px;
			}
			button
			{
				width:200px;
			}
			.log
			{
			float:right;
			width:100px;
			}
			
		</style>
	</head>
	<body>
	<div class="log">
		<label style="color:blue;">Login as ( <?php echo $name?>  )</label><a href="destroy.php">Logout</a>
	</div>
	<br>
		<h1 align="center">Home Page</h1>
		<br>
		<br><br>
		<div class="for"align="center">
			<a class="btn btn-primary"href="profile.php">Profile</a><br><br>
			<a class="btn btn-primary"href="delete.php">Delete</a><br><br>
			<a class="btn btn-primary"href="update.php">Update</a>
		</div>
	</body>
</html>