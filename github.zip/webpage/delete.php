<html>
	<?php
	session_start();
	include "connection.php";
	$usr=$_SESSION['use'];
	$query=mysql_query("select * from signup where username='$usr' ");
	$rows=mysql_fetch_array($query);
	$id=$rows['id'];
	
	if(isset($_POST["submit"]))
		{
		$uname=$_POST['username'];
		$upass=$_POST['password'];
		$uemail=$_POST['email'];
		$uphone=$_POST['phone'];
		$uaddr=$_POST['address'];
		$del=mysql_query("delete from signup where id=$id");
		if($del)
		{	
			echo "<script>";
			echo 'alert("delete successfully");';
			echo "</script>";
			header('Location:destroy.php');
		}
		}
	?>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"rel="stylesheet">
		<style>
			.for
			{
				width:700px;
				height:auto;
				border:0px solid #286090;
				padding:60px 30px;
				border-radius:15px;
				line-height:30px;
				margin:0px auto;
				-webkit-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				-moz-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
			}
			h1
			{
				font-family:ariel;
				color: white;
				font-size: 55px;
				text-shadow: rgb(2, 2, 3) -3px -3px 6px;

			}
			td,th
			{
				width:auto;
				height:40px;
				padding:10px;
				text-align:center;
			}
			.log
			{
			float:right;
			width:100px;
			}
			input{padding-left:15px;}
		</style>
	</head>
	<body>
	<div class="log">
		<label style="color:blue;">Login as ( <?php echo $usr?>  )</label><a href="destroy.php">Logout</a>
	</div>
		<h1 align="center">USER PROFILE</h1>
		<br>
		<div class="for"align="center"><form method="POST"action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"autocomplete="on">
		<form action="delete.php"method="post">
			Are you sure want to delete your account<br><br> <input type="submit"name="submit"class="btn btn-primary"value="Delete My Account">
			
		</form>
		</div>
	</body>
</html>