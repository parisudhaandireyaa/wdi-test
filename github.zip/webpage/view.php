
	<?php
		session_start();
		include "connection.php";
		$usr=$_SESSION['use'];
		$query=mysql_query("select * from signup");
	?>
	<html>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"rel="stylesheet">
		<style>
			.for
			{
				width:700px;
				height:auto;
				border:0px solid #286090;
				padding:60px 30px;
				border-radius:15px;
				line-height:30px;
				margin:0px auto;
				-webkit-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				-moz-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
			}
			h1
			{
				font-family:ariel;
				color: white;
				font-size: 55px;
				text-shadow: rgb(2, 2, 3) -3px -3px 6px;

			}
			td,th
			{
				width:auto;
				height:40px;
				padding:10px;
				border:1px solid black;
				text-align:center;
			}
			.log
			{
			float:right;
			width:140px;
			}
		</style>
	</head>
	<body>
		<div class="log">
			<label style="color:blue;">Login as ( <?php echo $usr?>  )</label><a href="destroy.php">Logout</a>
		</div>
		<h1 align="center">USER PROFILE</h1>
		<br>
		<div class="for"align="center">
			<table>
			
				<tr>
					<th>USERNAME</th>
					<th>PASSWORD</th>
					<th>EMAIL</th>
					<th>PHONE</th>
					<th>ADDRESS</th>
					<th>OPERATION</th>
				</tr>
				<?php
						while($rows=mysql_fetch_array($query))
						{
				?>
				<tr>
				
					<td><?php
							echo "$rows[username]";
						
						?>
					</td>
					<td>
						<?php
							echo "$rows[password]";
							
						?>					
					</td>
					<td>
						<?php
							echo "$rows[email]";
							
						?>					
					</td>
					<td>
						<?php
							echo "$rows[phone]";
							
						?>					
					</td>
					<td>
						<?php
							echo "$rows[address]";
						?>					
					</td>
					<td>
						<a href="del.php?id=<?php echo $rows['id'];?>">delete</a>
					</td>
				</tr>
				<?php } ?>
			</table>
		</div>
	</body>
</html>