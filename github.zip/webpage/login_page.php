<html>
	<head>
		<?php
		session_start();
		if ((isset($_SESSION['use']) && $_SESSION['use'] != '')) {

			header ("Location: home.php");

		}
		include "connection.php";
		if(isset($_POST["submit"]))
		{
			$name=$_POST['username'];
			$pass=$_POST['password'];
			$result=mysql_query("select * from signup");
			$query=mysql_fetch_array($result);			
			$query1=mysql_query("select * from signup where username='".$name."' and password='".$pass."'");
			if(mysql_num_rows($query1)>0)
			{
				$_SESSION['use']=$_POST['username'];
				$name=$_SESSION['use'];
				$query=mysql_query("select * from signup where username='$name' ");
				$rows=mysql_fetch_array($query);
				if($rows['roll']==1)
				{
				header('Location:view.php');
				}
				else
				{
				header('Location:home.php');
				}
			}
			else
			{
				echo "<script>";
				echo 'alert("User Name or Password MisMatched!").query';
				echo "</script>";
			}
		}
	?>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"rel="stylesheet">
		<style>
			.for
			{
				width:700px;
				height:300px;
				border:0px solid #286090;
				padding:60px 30px;
				border-radius:15px;
				line-height:30px;
				margin:0px auto;
				-webkit-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				-moz-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
			}
			h1
			{
				font-family:ariel;
				color: white;
				font-size: 55px;
				text-shadow: rgb(2, 2, 3) -3px -3px 6px;

			}
			.btn
			{
				width:270px;
				height:40px;
			}
			#txt1,#txt2
			{
				border-radius:5px;
				padding-left:15px;
				border:1px solid gray;
			}
			label
			{
				font-size:15px;
			}
		</style>
	</head>
	<body><br>
		<h1 align="center">Login Page</h1>
		<br><br><br>
		<div class="for"align="center">
		<form method="POST"action="login_page.php">
			<label>USER NAME:&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text"id="txt1"name="username"value="">
				<br><br>
			<label>PASSWORD:&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="password"id="txt2"name="password"value="">
			<br><br>
			<input type="submit"class="btn btn-primary"width="250px"value="submit"name="submit">
		</form>
			<a "class="btn btn-primary"width="250px"href="signup.php">Signup</a>
		</div>
	</body>
</html>