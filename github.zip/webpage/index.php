<?php
session_start();
if ((isset($_SESSION['use']) && $_SESSION['use'] != '')) {

			header ("Location: home.php");

		}
		?>
<html>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"rel="stylesheet">
		<style>
			.for
			{
				width:700px;
				height:200px;
				border:0px solid #286090;
				padding:60px 30px;
				border-radius:15px;
				line-height:30px;
				margin:0px auto;
				-webkit-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				-moz-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
			}
			h1
			{
				font-family:ariel;
				color: white;
				font-size: 55px;
				text-shadow: rgb(2, 2, 3) -3px -3px 6px;

			}
			td,th
			{
				width:300px;
				height:40px;
				padding:10px;
				border:1px solid black;
				text-align:center;
			}
			.link
			{
				font-size:20px;
				color:blue;
			}
			a:hover
			{
				width:100px;
				text-decoration:bold;
				text-color:green;
				font-family:serif;
			}
			
			
		</style>
	</head>
	<body>
		<h1 align="center">INDEX PAGE</h1>
		<br>
			<div class="for"align="center">
				<a href="login_page.php"class="link"id="login">Login</a>
				<br><br>
				<a href="signup.php"class="link"id="signup">Signup</a>
			</div>
</html>
