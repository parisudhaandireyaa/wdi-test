<?php
	include "connection.php";
	if(isset($_POST["submit"]))
		{
			echo "sdfsdf";
			$n=$_POST['username'];
			$p=$_POST['password'];
			$e=$_POST['email'];
			$ph=$_POST['phone'];
			$a=$_POST['address'];
			$query="INSERT INTO signup(`username`, `password`, `email`, `phone`, `address`,roll) VALUES ('$n','$p','$e','$ph','$a',2)";
			$result=mysql_query($query);
			if($result)
			{
				echo "<script>alert('login successfully........');</script>";
				header('Location:login_page.php');
			}
			else
			{
				echo "err";
			}
		}
?>

<html>
	<head>
	
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"rel="stylesheet">
		<script>
		function ch_name()
		{
				var n=document.getElementById("txt1").value;
				var e1=document.getElementById("err1");
				
		}
		function ch_pass()
		{
				var n=document.getElementById("txt2").value;
				var e1=document.getElementById("err2");
				if(n.length=="" || n==null)
				{
					e1.innerHTML="Password length must be 6";
				}
		}
		function ch_phone()
		{
				var n=document.getElementById("txt4").value;
				var e1=document.getElementById("err4");
				if(!isNaN(n))
				{
					e1.innerHTML=Phone number must be a number";
				}
		}
		function ch_email()
		{
				var n=document.getElementById("txt3").value;
				var e1=document.getElementById("err3");
				if(n=="" || n==null)
				{
					e1.innerHTML="Required";
				}
		}
		</script>
		<style>
			.for
			{
				width:700px;
				height:500px;
				border:0px solid #286090;
				padding:60px 30px;
				border-radius:15px;
				line-height:30px;
				margin:0px auto;
				-webkit-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				-moz-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
			}
			h1
			{
				font-family:ariel;
				color: white;
				font-size: 55px;
				text-shadow: rgb(2, 2, 3) -3px -3px 6px;

			}
			.btn
			{
				width:350px;
				height:40px;
			}
			
			label
			{
				font-size:15px;
			}
			td{padding:20px;	}
		</style>
	</head>
	<body>
		<h1 align="center">Sign up</h1>
		<br>
		<div class="for"align="center">
		<form method="POST"action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"autocomplete="on">
			<table>
				<tr>
					<td><label>USER NAME:&nbsp;&nbsp;&nbsp;&nbsp;</label></td>
					<td><input type="text"id="txt1"name="username"onblur="ch_name()"value="" required></td>
					<td><h6 id="err1"style="color:red"></h6></td>
				</tr>
				<tr>
					<td><label>PASSWORD:&nbsp;&nbsp;&nbsp;&nbsp;</label></td>
					<td><input type="text"id="txt2"name="password"value=""onblur="ch_pass()"required></td>
					<td><h6 id="err2"style="color:red"></h6></td>
				</tr>
				<tr>
					<td><label>EMAIL:&nbsp;&nbsp;&nbsp;&nbsp;</label></td>
					<td><input type="text"id="txt3"name="email"value=""onblur="ch_email()"required></td>
					<td><h6 id="err3"style="color:red"></h6></td>
				</tr>
				<tr>
					<td><label>PHONE:&nbsp;&nbsp;&nbsp;&nbsp;</label></td>
					<td><input type="text"id="txt4"name="phone"value=""onblur="ch_phone()"required></td>
					<td><h6 id="err4"style="color:red"></h6></td>
				</tr>
				<tr>
					<td><label>ADDRESS:&nbsp;&nbsp;&nbsp;&nbsp;</label></td>
					<td><input type="text"id="txt4"name="address"value=""onblur="ch_addr()"required></td>
					<td><h6 id="err5"style="color:red"></h6></td>
				</tr>
				<tr>
					<td colspan="2"><input type="submit"name="submit"class="btn btn-primary"width="250px"value="submit"><td>
				</tr>
			<table>
		</form>
		
		</div>
		<br><br><u><a href="index.php"style="float:right;"class="btn">Return to home page</a></u>
	</body>
</html>