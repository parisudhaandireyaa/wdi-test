<?php
	include "connection.php";
$id=$_GET['id'];
	
	if(isset($_GET['id']))
		{
		$del=mysql_query("delete from signup where id=$id");
		if($del)
		{	
			header('Location:view.php');
		}
	}
?>