<html>
	<?php
	include "connection.php";
		session_start();
		$usr=$_SESSION['use'];
		$query=mysql_query("select * from signup where username='$usr' ");
		$rows=mysql_fetch_array($query);
	?>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"rel="stylesheet">
		<style>
			.for
			{
				width:700px;
				height:auto;
				border:0px solid #286090;
				padding:60px 30px;
				border-radius:15px;
				line-height:30px;
				margin:0px auto;
				-webkit-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				-moz-box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
				box-shadow: 1px 3px 40px -5px rgba(0,0,0,0.75);
			}
			h1
			{
				font-family:ariel;
				color: white;
				font-size: 55px;
				text-shadow: rgb(2, 2, 3) -3px -3px 6px;

			}
			td,th
			{
				width:auto;
				height:40px;
				padding:10px;
				text-align:center;
			}
			.log
			{
			float:right;
			width:100px;
			}
		</style>
	</head>
	<body>
	<div class="log">
		<label style="color:blue;">Login as ( <?php echo $usr?>  )</label><a href="destroy.php">Logout</a>
	</div>
		<h1 align="center">USER PROFILE</h1>
		<br>
		<div class="for"align="center"><form method="POST"action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"autocomplete="on">
			<table>
				<tr>
					<td><label>USER NAME:&nbsp;&nbsp;&nbsp;&nbsp;</label></td>
					<td><input type="text"id="txt1"value="<?php echo $rows['username'];?>"name="username"onblur="ch_name()"value="" required readonly></td>
					
				</tr>
				<tr>
					<td><label>PASSWORD:&nbsp;&nbsp;&nbsp;&nbsp;</label></td>
					<td><input type="text"id="txt2"name="password"value="<?php echo $rows['password'];?>"onblur="ch_pass()"required readonly></td>
					
				</tr>
				<tr>
					<td><label>EMAIL:&nbsp;&nbsp;&nbsp;&nbsp;</label></td>
					<td><input type="text"id="txt3"name="email"value="<?php echo $rows['email'];?>"onblur="ch_email()"required readonly></td>
					
				</tr>
				<tr>
					<td><label>PHONE:&nbsp;&nbsp;&nbsp;&nbsp;</label></td>
					<td><input type="text"id="txt4"name="phone"value="<?php echo $rows['phone'];?>"onblur="ch_phone()"required readonly></td>
					
				</tr>
				<tr>
					<td><label>ADDRESS:&nbsp;&nbsp;&nbsp;&nbsp;</label></td>
					<td><input type="text"id="txt4"name="address"value="<?php echo $rows['address'];?>"onblur="ch_addr()"required readonly></td>
					
				</tr>
				
			<table>
		</form>
		</div>
	</body>
</html>