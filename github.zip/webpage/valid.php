<?php
	$aname=$_POST['ausername'];
	$apass=$_POST['apassword'];
	$query=mysql_query("select * from admin where username='".$aname."' and password='".$apass."'");
	if(mysql_num_rows($query)>0)
			{
				header('Location:connection.php');
			}
			else
			{
				echo "<script> ";
				echo 'alert("login failed")';
				echo "</script> ";
			}	
?>