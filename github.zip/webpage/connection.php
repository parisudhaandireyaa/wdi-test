<?php
	$con=mysql_connect("localhost","root","");;
	$conn=mysql_select_db("sample",$con);
	if(empty($conn))
	{
		die ("error");
	}
?>